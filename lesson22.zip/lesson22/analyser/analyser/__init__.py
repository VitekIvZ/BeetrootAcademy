from .text_handler import TextHandler
from .dict_handler import DictHandler
from .word_container import WordContainer