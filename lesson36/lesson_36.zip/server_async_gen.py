import socket
import select

HOST = '127.0.0.1'  # Standard loop-back interface address (localhost)
PORT = 65432        # Port to listen on (non-privileged ports are > 1023)


tasks = []
to_read = {}
to_write = {}


def server():
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.bind((HOST, PORT))
    sock.listen(1)

    while True:
        yield 'read', sock
        conn, addr = sock.accept()
        print(f"Connection from {addr}")
        tasks.append(client_socket(conn, addr))

    # sock.setblocking(False)


def client_socket(conn, addr):
    while True:
        print("Before client receive")
        yield 'read', conn
        result = conn.recv(1024)
        print('Received message', result.decode('utf-8'))
        
        if not result:
            break
        else:
            yield 'write', conn
            conn.send(result.upper())
    print(f"Closed conn from {addr}")   
    conn.close()


def event_loop():
    while any([tasks, to_read, to_write]):

        while not tasks:
            ready_to_read, ready_to_write, _ = select.select(to_read, to_write, [])
            for sock in ready_to_read:
                tasks.append(to_read.pop(sock))
            for sock in ready_to_write:
                tasks.append(to_write.pop(sock))

        try:
            task = tasks.pop(0)

            op_type, sock = next(task)
            if op_type == "read":
                to_read[sock] = task
            if op_type == "write":
                to_write[sock] = task

        except KeyboardInterrupt:
            break
        except StopIteration:
            print("Done")
        

if __name__ == '__main__':
    gen = server()
    tasks.append(gen)

    event_loop()