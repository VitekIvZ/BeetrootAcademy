import time

class CustomException(Exception):
    pass


def coroutine(func):
     def wrapper(*args, **kwargs):
          gen = func(*args, **kwargs)
          gen.send(None)
          return gen
     return wrapper


#@coroutine
def subgen():
    # for i in "asdgsa":
    #     yield i
    while True:
        try:
            message = yield
        except StopIteration as e:
            print("Done")
            break
        except CustomException:
            print("Warning!")
        else:
            print(".......", message)
    return "Gen was finished"


@coroutine   
def delegator(g):
    # for i in g:
    #     yield i
    # while True:
    #     try:
    #         data = yield
    #         g.send(data)
    #     except CustomException as err:
    #         g.throw(err)

    result = yield from g   # await
    return result
            

if __name__ == '__main__':
    sg = subgen()
    g = delegator(sg)

    # for el in g:
    #     print(el, end=' ')
    # print()
    g.send("ok")

    g.throw(CustomException)

    try: 
        g.throw(StopIteration)
    except StopIteration as err:
        print(err.value)

    # print(result)

