import asyncio
import time


def concat_seq_1(s1, s2):
    for el in s1:
        yield el
    for el in s2:
        yield el


# gen = concat_seq_1([1, 2, 3, 7], [5, 8, 44, 9, 2])


def concat_seq_2(s1, s2):
        yield from s1
        yield from s2


def coroutine(func):
     def wrapper(*args, **kwargs):
          gen = func(*args, **kwargs)
          gen.send(None)
          return gen
     return wrapper


@coroutine
#@asyncio.coroutines
def is_devider(number):

    while True:
        value = yield
        if number % value == 0:
             print(value)


def sync_worker(number, divider):
     print(f"Sync worker started: {number} / {divider}")
     time.sleep(1)
     print(number / divider)


# @coroutine
async def async_worker(number, divider):
     print(f"Async worker started: {number} / {divider}")
     await asyncio.sleep(1)
     print(number / divider)
     return number / divider


async def gather_workers():
     
     result = await asyncio.gather(
          async_worker(50, 5),
          async_worker(50, 10),
          async_worker(50, 25),
          async_worker(50, 35)
     )

     print(result)


async def stop_event_loop(loop, seconds):
     print(f"Loop is stoping in {seconds} seconds")
     await asyncio.sleep(seconds)
     loop.stop()
     print("Loop stoped!")


async def handle_future(future):
     await asyncio.sleep(4)
     future.set_result(10)


async def wait_for_future(future):
     result = await future
     print(f"Future result: {result}")


def long_process(start=0, finish=1000):
    result = 0
    for _ in range(start, finish):
        result += 1
    return result


async def executor(loop, start, finish):
     print("Executor sterted")
     result = await loop.run_in_executor(None, long_process, start, finish)
     print(f'Result: {result}')


if __name__ == '__main__':
    # gen = concat_seq_2([1, 2, 3, 7], [5, 8, 44, 9, 2])

    # for elem in gen:
    #     print(elem)
    # gen = is_devider(100)

    # gen.send(10)
    # gen.send(20)

    # gen.close()

    # print(sync_worker(10, 5))
    # print(sync_worker(10, 2))

    event_loop = asyncio.get_event_loop()

    fut = asyncio.Future()

    # task_list = [
    #     #  event_loop.create_task(async_worker(50, 5)),
    #     #  event_loop.create_task(async_worker(50, 10))
    #     event_loop.create_task(gather_workers())
    # ]
    # tasks = asyncio.wait(task_list)

    # event_loop.run_until_complete(tasks)

    # event_loop.create_task(stop_event_loop(event_loop, 10))
    # event_loop.create_task(handle_future(fut))
    # event_loop.create_task(wait_for_future(fut))

    # event_loop.run_forever()
    tasks = asyncio.wait(
         [
              event_loop.create_task(executor(event_loop, 0, 2**26)),
              event_loop.create_task(executor(event_loop, 0, 2**26)),
         ]
    )
    event_loop.run_until_complete(tasks)
    event_loop.close()