
class CustomException(Exception):
    pass


def coroutine(func):
     def wrapper(*args, **kwargs):
          gen = func(*args, **kwargs)
          gen.send(None)
          return gen
     return wrapper


@coroutine
def average():
    count = 0
    summ = 0
    average_ = None

    while True:
        try:
            x = yield average_
        except CustomException:
            print("Custopm Exception")
        except StopIteration:
            print('Done')
            break
        else:
            count += 1
            summ += x
            average_ = summ / count
    return average_



