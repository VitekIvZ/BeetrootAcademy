import socket
import asyncio

HOST = '127.0.0.1'  # Standard loop-back interface address (localhost)
PORT = 65432        # Port to listen on (non-privileged ports are > 1023)


async def server():
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.bind((HOST, PORT))
    sock.listen(1)

    loop = asyncio.get_event_loop()

    while True:
        conn, addr = await loop.sock_accept(sock)
        print(f"Connection from {addr}")
        loop.create_task(client_socket(conn, addr))

    # sock.setblocking(False)


async def client_socket(conn, addr):
    loop = asyncio.get_event_loop()

    while True:
        print("Before client receive")

        result = await loop.sock_recv(conn, 1024)
        print('Received message', result.decode('utf-8'))
        
        if not result:
            break
        else:
            await loop.sock_sendall(conn, result.upper())
    print(f"Closed conn from {addr}")   
    conn.close()


if __name__ == '__main__':
    
    asyncio.run(server())