import unittest
from calc import add, div, CustomZeroDivision


class CalcTest(unittest.TestCase):
    """Calc tests"""

    @classmethod
    def setUpClass(cls):
        """Set up for class"""
        print("setUpClass")
        print("==========")

    def setUp(self):
        """Set up for test"""
        print(f"Set up for [{self.shortDescription()}]")

    def test_div(self):
        """Div operation test"""
        self.assertEqual(div(1, 2), 0.5)
        self.assertAlmostEqual(div(1, 2), 0.50000001)

    def test_div_zero(self):
        with self.assertRaises(CustomZeroDivision):
            div(1, 0)

    def test_add(self):
        """Add operation test"""
        self.assertEqual(add(1, 2), 3)
        self.assertNotEqual(add(-10, 12), -2)

    def tearDown(self):
        print(f"Tear down for [{self.shortDescription()}]")

    @classmethod
    def tearDownClass(cls):
        """Tear down for class"""
        print("tearDownClass")
        print("==========")


if __name__ == '__main__':
    unittest.main()