from calc import add, div, CustomZeroDivision


def test_add():
    if add(1, 2) == 3:
        print("TEst add(x, y) is ok")
    else:
        print("TEst add(x, y) is fail")
    # assert add(1, 2) == 3, f"TEst add({1}, {2}) != {3}"


def test_div():
    if div(1, 2) == 0.5:
        print("TEst div(x, y) is ok")
    else:
        print("TEst div(x, y) is fail")
    try:
        div(1, 0)
    except CustomZeroDivision as err:
        print(f"Test div(x, o) by zero is ok: {err}")
    assert div(4, 2) == 2, f"TEst add({1}, {2}) != {3}"


if __name__ == '__main__':
    test_add()
    test_div()


