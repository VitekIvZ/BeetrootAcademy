class CustomZeroDivision(ZeroDivisionError):
    pass


def add(x, y):
    """ """
    return x + y


def div(x, y):
    if y != 0:
        return x / y
    else:
        raise CustomZeroDivision("")