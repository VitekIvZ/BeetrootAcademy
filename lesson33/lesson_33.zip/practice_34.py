import threading
from time import time

# I/O - bounded
# CPU - bounded 

def long_process_1(start=0, finish=1000):
    result = 0
    for i in range(start, finish):
        result += 1
    results.append(result)
    thread_data.value = result
    print(f"Result: {result}")


def long_process(start=0, finish=1000):
    result = 0
    for i in range(start, finish):
        result += 1
    results.append(result)
    print(f"Result: {result}")


if __name__ == '__main__':
    results = []
    thread_data = threading.local()
    params = {'start': 0, 'finish': 2**24}
    task = threading.Thread(target=long_process_1, kwargs=params)

    started = time()

    task.start()

    task.join()

    # print(thread_data.value)

    print(f"Run thread time: {time()-started:.3f}")

    started = time()

    long_process(**params)

    print(f"Run main time: {time()-started:.3f}")


    task1 = threading.Thread(target=long_process, kwargs={'start': 0, 'finish': 2**23}, name='Task1')
    task2 = threading.Thread(target=long_process, kwargs={'start': 2**23, 'finish': 2**24}, name='Task2')

    started = time()

    task1.start()
    task2.start()

    # print(task1.is_alive(), task2.is_alive())
    # print(results, thread_data.value)

    task1.join()
    task2.join()
    
    print(f"Run 2 threads time: {time()-started:.3f}")
    # print(task1.is_alive(), task2.is_alive())
    print(results)





