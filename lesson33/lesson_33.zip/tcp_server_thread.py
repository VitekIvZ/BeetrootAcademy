import socket
import threading


HOST = '127.0.0.1'  # Standard loop-back interface address (localhost)
PORT = 65432        # Port to listen on (non-privileged ports are > 1023)


class TCPServer:

    def __init__(self, host, port):
        self.host = host
        self.port = port
        self.clients = []
        self.server = None
        self.init_sertver()

    def init_sertver(self):
        self.server = server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        server.bind((self.host, self.port))
        server.listen(5)
        # return server


    def start_server(self):
        server = self.server
        # server.setblocking(False)
        while True:
            try:
                client, addr = server.accept()
                self.clients.append((client, addr))
                print('Connected by', addr)
            except socket.error:
            # print('no client')
                pass
            else:
                threading.Thread(target=self.handle_client, args=(client, addr), daemon=True).start()
                print([cl[1] for cl in self.clients])

    def handle_client(self, client, addr):
        client.setblocking(True)
        while True:
            result = client.recv(1024)
            if not result:
                break
            print('Message', result.decode('utf-8'))
            client.send(result.upper())
        
        client.close()
        self.clients.remove((client, addr))
    
    def __del__(self):
        for client, _ in self.clients:
            client.close()
        self.server.close()
        print("server closed!")


if __name__ == '__main__':
    server = TCPServer(HOST, PORT)
    
    threading.Thread(target=server.start_server, daemon=True).start()

    while True:
        try:
            pass
        except KeyboardInterrupt:
            del server
            break

