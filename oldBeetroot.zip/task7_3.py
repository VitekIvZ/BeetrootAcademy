#task7_3.py

"""
List comprehension exercise

Use a list comprehension to make a list containing tuples (i, j) 
where 'i' goes from 1 to 10 and 'j' is corresponding to 'i' squared.
"""
MIN_ITER = 1
MAX_ITER = 10


def config_tuples():
    squared_tuples = [(i, i**2) for i in range(MIN_ITER, MAX_ITER + 1)]
    
    return squared_tuples
            
if __name__ == "__main__":     
    squared_tuples = config_tuples()
    print(squared_tuples)

