#task5_2.py

import sys



def greet_user(age):
      next_birthday_age = age + 1
      return next_birthday_age
    

if __name__ == "__main__":
      
      if len(sys.argv) > 1:
            name = sys.argv[1]  
            age = int(sys.argv[2])
      else:
            name = input("Будь ласка, введіть ваше ім'я: ")
            age = int(input("Будь ласка, введіть ваш вік: "))
            
      next_birthday_age = greet_user(age)
      print(f"Привіт, {name}, на твоєму наступному дні народження тобі буде {next_birthday_age} років.")


