#Which statement of the following alternatives is equal to the variable str_c?

str_c = [1, 3].extend([9, 27])
str_c = [1, 3] + [9, 27]
