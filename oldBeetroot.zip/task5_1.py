#task5_1.py

import random

def guess_number():
    random_number = random.randint(1, 10)
    return random_number
    
    
if __name__ == "__main__":
    
    attempts = 0  # Лічильник спроб
    random_number = guess_number()
        
    print("Я загадав число між 1 і 10. Спробуй вгадати!")

    while True:
        
        user_guess = int(input("Введи своє припущення: "))
        attempts += 1  # Збільшення лічильника спроб

        if user_guess == random_number:
            print(f"Вітаю! Ти вгадав число {random_number} за {attempts} спроб.")
            break  # Вихід з циклу
        else:
            print("Неправильно. Спробуй ще раз!")

