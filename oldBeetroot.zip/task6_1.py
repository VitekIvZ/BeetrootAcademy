#task6_1.py

#The greatest number

import random

# Generate a list of 10 random numbers
def gen_number():
    numbers = []
    while len(numbers) < 10:
        number = random.randint(1, 100)
        numbers.append(number)
    return numbers

# Find the largest number
def find_largest():
    largest = 0
    numbers = gen_number()
    index = 0
    while index < len(numbers):
        if numbers[index] > largest:
            largest = numbers[index]
        index += 1
    return largest
            
if __name__ == "__main__":     
    
    largest = find_largest()

    # Print the largest number
    print("The largest number is", largest)

