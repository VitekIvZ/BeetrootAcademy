import sys

def convert_d_to_b(n):
    b_list = []
        
    while n > 0:
        b_list.append(n % 2)
        n = n // 2

    b_list.reverse()
    return ''.join(map(str, b_list))

if __name__ == "__main__":    
    
    if len(sys.argv) > 1:
          n = int(sys.argv[1])
         
    else:
          n = int(input("Please enter number: "))        
    
    b_list = convert_d_to_b(n)
    print(b_list)
    
    

