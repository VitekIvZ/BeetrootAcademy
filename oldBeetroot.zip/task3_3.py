#task3_3.py

a, b = map(int, input("Enter two numbers: ").split())

# Print the results calculate
print(f"Addition: {a} + {b} = {a + b}")
print(f"Subtraction: {a} - {b} = {a - b}")
print(f"Division: {a} / {b} = {round(a / b, 2)}")
print(f"Multiplication: {a} * {b} = {a * b}")
print(f"Exponent (Power): {a} ** {b} = {a ** b}")
print(f"Modulus: {a} % {b} = {a % b}")
print(f"Floor Division: {a} // {b} = {a // b}")
