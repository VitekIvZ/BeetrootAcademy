#task10_1.py


def oops():
    raise IndexError("This is an IndexError")


def oops_2():
    raise KeyError("This is a KeyError")


def catch_oops():
    try:
        oops()
    except IndexError as e:
        print(f"Caught an exception: {e}")


def catch_oops_2():
    try:
        oops_2()
    except IndexError as e:
        print(f"Caught an exception: {e}")
        
if __name__ == "__main__":
    
    catch_oops()

    catch_oops_2()