import random as rm

# while "<condition>":

#     pass


# while ():

#     if <condition>:
#         break
#     pass


# else:
#     print("done")


# while True:

#     if <condition>:
#         break
#     pass


def max_from_list(lst):
    max_val = lst[0]
    i = 1
    while i < len(lst):
        if max_val < lst[i]:
            max_val = lst[i]
        i += 1
    return max_val


def max_min_from_list(lst):
    max_val = lst[0]
    min_val = lst[0]
    i = 1
    while i < len(lst):
        if max_val < lst[i]:
            max_val = lst[i]
        if min_val > lst[i]:
            min_val = lst[i]
        i += 1
    return max_val, min_val


def average_list(lst):
    sum_val = lst[0]
    i = 1
    while i < len(lst):
        sum_val += lst[i]
        i += 1
    return sum_val / len(lst)


def reverse(lst):
    i = 0
    while i < len(lst)//2:
        lst[i], lst[-(i+1)] = lst[-(i+1)], lst[i]
        i += 1
    return lst


def uniq_elem_list(lst):

    res_list = list()
    i = 0
    while i < len(lst):
        if lst.count(lst[i]) == 1:
            res_list.append(lst[i]) 
        i += 1
    return res_list


if __name__ == '__main__':
    # lst = [1, 2, 3, 4, 5, 6]   #  5 // 2 = 2, [1, 2, 3, 4, 5, 6]  6 // 2 = 3
    # print(f"max value of list {lst} = {max_from_list(lst)}")
    # print(f"average value of list {lst} = {average_list(lst):g}")

    # max_v, min_v = max_min_from_list(lst)
    # max_min = max_min_from_list(lst)
    # print(type(max_min), max_min, max_min[0], max_min[1])
    # print(type(max_v), max_v, type(min_v), min_v)

    # print(f"reverse value of list {lst, id(lst)} = {reverse(lst), id(lst)}")

    # print('before reverse', id(lst))
    # print(lst.reverse())
    # print('after reverse', id(lst))

    # # lst.insert(0, 0)
    # print(lst)

    range(0, 10, 2)

    # lst_r = list(reversed(lst))
    # print(lst_r, id(lst_r))

    # lst2 = lst[:]

    # temp = lst[0]
    # lst[0] = lst[-1]
    # lst[-1] = temp

    # lst[0], lst[-1] = lst[-1], lst[0]

    # print(lst[0], lst[-1])
    # print(id(lst), id(lst2))

    # del lst_r[::3]
    # print(lst_r)
    # print(lst_r.pop())

    # a = [5, 6, 7]
    # print('a  before: ', id(a)) 
    # a += [8, 9]      # a.extend([8, 9]), a.append(8)
    # print('a  after: ', id(a)) 


    # b = [5, 6, 7]
    # print('b  before: ', id(b))
    # b = b + [8, 9]    # <!=> b.extend([8, 9]) 
    # print('b  after: ', id(b)) 


    # word = 'hello'
    # for _ in range(len(word)):
    #     print(rm.choice(word))

    # print(''.join(rm.sample(word, len(word))))

    lst = [1, 1, 2, 2, 2, 3, 4, 5, 6, 7]
    # print(lst)
    uniq_elems = set(lst)
    new_list = list(uniq_elems)
    # print("distiq ", new_list)

    elems = list(map(int, "".split()))
    # print(uniq_elem_list([4, 3, 5, 2, 5, 1, 3, 5]))

    con1 = set(map(int, "1 2 6 4 5 7".split()))
    con2 = set(map(int, "10 2 3 4 8".split()))

    # print(len((con1 - con2)|(con2 - con1)))
    # print(len(con1 ^ con2))

    # print(len(con1 & con2))

    text = """She sells sea shells on the sea shore;
The shells that she sells are sea shells I'm sure.
So if she sells sea shells on the sea shore,
I'm sure that the shells are sea shore shells.
"""
    signs = ';,.'
    for sign in signs:
        text = text.lower().replace(sign, '')
    # word_list = sorted(list(set(text.split())))
    # print(sorted(list(set(text.split()))))


    con = list(map(int, "1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1".split()))
    # con = list(map(int, "10 10 4 2 5 5 10 4 1 10".split()))

    s = set()
    res = []
    # i = 0
    # while i < len(con):
    #     if con[i] not in s:
    #         s.add(con[i])
    #         res.append('N')
    #     else:
    #         res.append('Y')
    #     i += 1

    # for i in range(len(con)):
    #     if con[i] not in s:
    #         s.add(con[i])
    #         res.append('N')
    #     else:
    #         res.append('Y')

    for element in con:
        if element not in s:
            s.add(element)
            res.append('N')
        else:
            res.append('Y')

    print(''.join(map("{:^3}".format, con)))
    # print(' '.join( map(str, con) )  )
    print(''.join(map("{:^3}".format, res)))

    # [str(10), "{:3}".format(10), ]

