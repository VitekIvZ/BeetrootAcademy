import sys

# Generate a list of people from 1 to n
def gen_list(n):
    numbers = []
    i = 1
    
    while i <= n:
        numbers.append(i)
        i += 1
        
    return numbers


def josephus(n, k):
    numbers = gen_list(n)
    index = k - 1
    
    while len(numbers) > (k - 1):
        del numbers[index]
        index = (index + (k-1)) % len(numbers)
                 
    return numbers

if __name__ == "__main__":     
    
    if len(sys.argv) > 1:
        n = int(sys.argv[1])  
        k = int(sys.argv[2])
    else:
        n, k = map(int, input("Enter two numbers for n and k: ").split())       
    
    last_person = josephus(n, k)  
    print(f"Останні на позиції: {last_person}")
