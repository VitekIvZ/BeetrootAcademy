#task7_1.py

"""
Make a program that has some sentence (a string) on input and 
returns a dict containing all unique words as keys and the number of occurrences as values. 
"""

def count_word_occurrences(sentence):
    # Remove punctuation and convert to lower case
    words = sentence.lower().replace('.', '').replace(',', '').replace('!', '').split()
    
    # Create a dictionary to hold word counts
    word_count = {}
    
    for word in words:
        word_count[word] = word_count.get(word, 0) + 1
    
    return word_count
            
if __name__ == "__main__":     
    
    input_sentence = "Hello world! Hello everyone. Welcome to the world."
    result = count_word_occurrences(input_sentence)
    print(result)

