#task6_3.py

#Extracting numbers.


# Generate a list of integers from 1 to 100
def gen_numbers():
    numbers = []
    i = 1
    while i <= 100:
        numbers.append(i)
        i += 1
    return numbers

# Find the integers that are divisible by 7 but not a multiple of 5
def find_integers():
    numbers = gen_numbers()
    list7not5 = []
    index = 0
    while index < len(numbers):
        if numbers[index] % 7 == 0 and numbers[index] % 5 != 0:
            list7not5.append(numbers[index])
        index +=1
    return list7not5

if __name__ == "__main__":     
    
    list7not5 = find_integers()

    # Print the list
    print("The integers that are divisible by 7 \nbut not a multiple of 5 are:", list7not5)