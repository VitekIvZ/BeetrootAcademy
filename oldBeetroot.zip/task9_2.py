
#task9_2.py

"""

The sys module.

 The “sys.path” list is initialized from the PYTHONPATH environment variable. 
 Is it possible to change it from within Python? 
 If so, does it affect where Python looks for module files? 
 Run some interactive tests to find it out.
"""

import sys


if __name__ == "__main__":

    # Check initial sys.path
    print("Initial sys.path:")
    print(sys.path)
    print(sys.path[-1])

    # Add a new path
    sys.path.append('/home/MyPython/Beetroot/task9_1')

    # Check sys.path after modification
    print("\nModified sys.path:")
    print(sys.path)
    print(sys.path[-1])
