def runningSum(nums):
    for i in range(1, len(nums)):
        nums[i] += nums[i-1]
        return nums
    
def maximum_wealth(accounts):
    max_wealth = 0
    for account in accounts:
        wealth = sum(account)
        if wealth > max_wealth:
            max_wealth = wealth
    return max_wealth


def list_to_string(lst1, lst2):
    result = []
    result_reverse = []  
    lst1_reverse = []
    lst2_reverse = []
    
    for num in lst1:
        lst1_reverse.insert(0, num)
        
    for num in lst2:
        lst2_reverse.insert(0, num)
                
    num1 = int(''.join(map(str, lst1_reverse)))
    num2 = int(''.join(map(str, lst2_reverse)))
    sum = num1 + num2
    
    for digit in str(sum):
        result.append(int(digit))
        
    for num in result:
        result_reverse.insert(0, num)
             
    return result_reverse

    
if __name__ == "__main__":
    nums = [1,2,3,4]
    print(runningSum(nums))
   
    accounts = [[1, 5], [7, 3], [3, 5]]
    print(maximum_wealth(accounts))  
    
    list1 = [2, 4, 3]
    list2 = [5, 6, 4]
    result = list_to_string(list1, list2)
    print(result)  # Output: "157335"