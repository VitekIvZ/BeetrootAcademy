#task3_1.py

name = input("Enter your name: ")
day = input("Enter day: ")

# Using f-string 
print(f"Good day {name}! {day} is a perfect day to learn some python.")

# Using format() method
print("Good day {}! {} is a perfect day to learn some python.".format(name, day))

# Using % formatting
print("Good day %s! %s is a perfect day to learn some python." % (name, day))

