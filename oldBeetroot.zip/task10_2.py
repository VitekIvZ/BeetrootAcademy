#task10_2.py


import sys


def calculate(a, b):
    try:
        return f"{(float(a) ** 2) / float(b):.2f}"
    except ValueError:
        return "Error: Both inputs must be numbers."
    except ZeroDivisionError:
        return "Error: Division by zero is not allowed."
    
    
if  __name__ == "__main__": 
    
    if len(sys.argv) > 1:
        a = sys.argv[1]
        b = sys.argv[2]
    else:
        a = input("Enter the first number (a): ")
        b = input("Enter the second number (b): ")
    result = calculate(a, b)

    print(result)