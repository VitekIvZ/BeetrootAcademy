# task3.py

print("#########\n#\t#\n#\t#\n#\t#\n#########\n")



print("#\t#\n#\t#\n#########\n#\t#\n#\t#")



