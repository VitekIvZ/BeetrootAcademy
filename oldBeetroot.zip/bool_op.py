import os, sys

PI = 3.14

def three_number(num1, num2, num3):
    """
    0 - different
    2 - 2 eq
    3 - eq
    """
    # if num1 != num2 != num3:
    #     return 0
    # elif num1 == num2 != num3 or num2 == num3 != num1 or num1 == num3 != num2:
    #     return 2
    # elif num1 == num2 == num3:
    #     return 3
    if num1 == num2 == num3:
        return 3
    elif num1 == num2 or num2 == num3 or num1 == num3:
        return 2
    else:
        return 0
    

def main():
    print("{}, {}, {} <=> {}".format(1, 2, 3, three_number(1, 2, 3)))
    print("{}, {}, {} <=> {}".format(2, 2, 3, three_number(2, 2, 3)))
    print("{}, {}, {} <=> {}".format(2, 2, 2, three_number(2, 2, 2)))
    print(__name__, __file__)


if __name__ == "__main__":
    main()
# else:
#     print("bool_op")