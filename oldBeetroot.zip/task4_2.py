#task4_2.py

#The valid phone number program.


phone_number = input("Enter phone number: ")

if len(phone_number) != 10:
    print("The phone number is not 10 characters long.")
elif not phone_number.isdigit():
    print("The phone number contains non-numerical characters.")
else:
    print("The phone number is in the right format.")


