# task11_1_1.py


def write_to_file(fileName, text):
    with open(fileName, "w") as file:
        file.write(text)
        
        
if __name__ == "__main__":
    write_to_file(fileName="myfile.txt", text="Hello file world!\n")