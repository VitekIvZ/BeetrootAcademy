#task6_2.py

#Exclusive common numbers.


import random

# Generate a list of 10 random numbers
def gen_number():
    numbers = []
    while len(numbers) < 10:
        number = random.randint(1, 10)
        numbers.append(number)
    return numbers

# Find the common integers between the 2 lists
def find_common():
    list1 = gen_number()
    list2 = gen_number()
    common = []
    index = 0 
    
    while index < len(list1):
        if list1[index] in list2 and list1[index] not in common:
            common.append(list1[index])
        index += 1
    return common
            
if __name__ == "__main__":     
    
    common = find_common()

    # Print the common integers
    print("The common integers are:", common)

