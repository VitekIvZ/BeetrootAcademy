#task4_3.py

#The math quiz program.

answer = int(input("Enter true answer of 2 + 2 = : "))

if answer == 4:
    print("Correct!")
else:
     print("Incorrect. The correct answer is '4'.")

