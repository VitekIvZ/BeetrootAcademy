#task5_3.py

import sys

import random

def generate_random_strings(input_string, num_strings=5):
    random_strings = []
    
    for _ in range(num_strings):
        random_string = ''.join(random.sample(input_string, len(input_string)))
        random_strings.append(random_string)
    
    return random_strings


if __name__ == "__main__":
    
    if len(sys.argv) > 1:
          input_string = sys.argv[1]  
         
    else:
          input_string = input("Please enter a string: ")    
    
    random_strings = generate_random_strings(input_string)
    
    print("Random strings generated:")
    
    for s in random_strings:
        print(s)
