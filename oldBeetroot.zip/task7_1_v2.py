import string

"""
Make a program that has some sentence (a string) on input and 
returns a dict containing all unique words as keys and the number of occurrences as values.
"""

def count_word_occurrences(sentence):
    # Create a translation table to remove punctuation
    #translator = str.maketrans('', '', string.punctuation)
        
    # Remove punctuation and convert to lower case
    #words = sentence.lower().translate(translator).split()
    words = [''.join([x for x in text if x not in string.punctuation]) for text in sentence.lower().split()]
        
    # Create a dictionary to hold word counts
    word_count = {}
    
    for word in words:
        word_count[word] = word_count.get(word, 0) + 1
    
    return word_count
            
if __name__ == "__main__":
    input_sentence = "Hello world! Hello everyone. Welcome to the world."
    result = count_word_occurrences(input_sentence)
    print(result)

