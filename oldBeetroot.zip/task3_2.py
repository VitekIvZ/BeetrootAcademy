#task3_2.py

first_name = input("Enter first name: ")
last_name = input("Enter last name: ")

print("Hello, " + first_name + " " + last_name + "! Welcome!")

