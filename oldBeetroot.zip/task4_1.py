#task4_1.py

#String manipulation

input_string = input("Enter string: ")

if len(input_string) < 2:
    print("")
else:
    print(input_string[:2]+input_string[-2:])
    

