# task11_1_2.py


def read_from_file(fileName):
    with open(fileName, "r") as file:
        return file.read()
        
        
if __name__ == "__main__":
    print(read_from_file(fileName="myfile.txt"))