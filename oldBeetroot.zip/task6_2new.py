import random

list1 = [random.randint(1, 10) for i in range(10)]
list2 = [random.randint(1, 10) for i in range(10)]

common = list(set(list1) & set(list2))

print(common)