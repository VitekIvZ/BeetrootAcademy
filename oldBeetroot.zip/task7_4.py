#task7_4.py

"""
1. Створити лист із днями тижня.
2. В один рядок (ну або як завжди) створити словник виду: {1: "Monday", 2:...
3. Також в один рядок або як вдасться створити зворотний словник {"Monday": 1,

"""
DAYES_OF_WEEK = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]

def gen_days_dict():
    days_dict = {i: day for i, day in enumerate(DAYES_OF_WEEK, start = 1)}
    return days_dict 

def gen_reverse_days_dict():
    reverse_days_dict = {day: i for i, day in enumerate(DAYES_OF_WEEK, start = 1)}
    return reverse_days_dict 

            
if __name__ == "__main__":   
    days_dict = gen_days_dict()
    reverse_days_dict = gen_reverse_days_dict()
    print(days_dict)
    print(reverse_days_dict)
    
    

