#task4_4.py

#The name check.


name = "anton"

given_name = input("Enter your name: ")

if given_name.lower() == name:
    print("True")
else:
    print("False")