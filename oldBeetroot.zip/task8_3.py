#task8_3.py

"""
A simple calculator.

Create a function called make_operation, which takes in a simple arithmetic operator 
as a first parameter (to keep things simple let it only be '+', '-' or '*') 
and an arbitrary number of arguments (only numbers) as the second parameter. 
Then return the sum or product of all the numbers in the arbitrary parameter. 
For example:

    the call make_operation('+', 7, 7, 2) should return 16
    the call make_operation('-', 5, 5, -10, -20) should return 30
    the call make_operation('*', 7, 6) should return 42  
"""

def make_operation(operator, *args):
    if not args:
        return 0  

    #operations = {
    #    '+': lambda x: sum(x),
    #    '-': lambda x: x[0] - sum(x[1:]),
    #    '*': lambda x: eval('*'.join(map(str, x)))  
    #}
    result = (lambda operator, x: eval(operator.join(map(str, x))))(operator, args) 
    return result

    #if operator in operations:
    #    return operations[operator](args)
    #else:
    #    raise ValueError("Invalid operator. Use '+', '-', or '*'.")
    
if __name__ == "__main__":  
    result = make_operation('/', 5, 5, -10, -20)
    print(result)       


