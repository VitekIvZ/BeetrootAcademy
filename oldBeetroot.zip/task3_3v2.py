#task3_3.v2.py

import sys


def add(a, b):
    return a + b

def subtract(a, b):
    return a - b

def divide(a, b):
    if b == 0:
        return 0
    else:
        return a / b

def multiply(a, b):
    return a * b

def exponent(a, b):
    return a ** b

def modulus(a, b):
    if b == 0:
        return 0
    else:    
        return a % b

def floor_division(a, b):
    if b == 0:
        return 0
    else:    
        return a // b


if __name__ == "__main__":
    
    if len(sys.argv) > 1:
        a = int(sys.argv[1])  
        b = int(sys.argv[2])
    else:
        a, b = map(int, input("Enter two numbers: ").split())    
    
    print(f"Addition: {add(a, b)}")
    print(f"Subtraction: {subtract(a, b)}")
    print("Division: {:.2f}".format(divide(a, b)))
    print(f"Multiplication: {multiply(a, b)}")
    print(f"Exponent (Power): {exponent(a, b)}")
    print(f"Modulus: {modulus(a, b)}")
    print(f"Floor Division: {floor_division(a, b)}")