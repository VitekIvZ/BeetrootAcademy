# task2.py

# Hello, world!
print("Hello, world!")


# Hello world !
print("Hello", "world", "!")


# Hello-world-!
print("Hello", "world", "!", sep="-")


# Hello world!
print("Hello", "world", end="")
print("!")


# Hello*world***!
print("Hello", "world", sep="*", end="***")
print("!")
