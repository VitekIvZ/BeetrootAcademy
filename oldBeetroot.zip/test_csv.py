import csv
import os

print("Поточна робоча директорія:", os.getcwd())

file_path = "/home/vitek/MyPython/Beetroot/logs.txt"

print(os.path.exists(file_path))

try:
    with open(file_path, "r") as f:
        reader = csv.reader(f)
        for row in reader:
            print(row)
except FileNotFoundError:
    print("Файл 'sample2.csv' не знайдено.")
except Exception as e:
    print(f"Виникла помилка: {e}")
