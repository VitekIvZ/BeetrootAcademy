#task9_1-1.py


def add_numbers(num1, num2):
    """Returns the sum of two numbers."""
    return num1 + num2


if __name__ == "__main__": 
    
    result = add_numbers(7, 6)
    print(result)  