from django.forms import Form, CharField, SlugField, Textarea, TextInput
from django.forms import ModelForm
from django.core.exceptions import ValidationError
from .models import Post, Tag


class PostForm(ModelForm):
# class PostForm(Form):
#     title = CharField(max_length=100)
#     slug = SlugField(max_length=100)
#     body = CharField(required=False, 
#                      widget=Textarea(attrs={'rows': 5, 'cols': 40}), 
#                      label="Text")

#     def save(self):
#         post = Post.objects.create(
#             title=self.cleaned_data['title'], 
#             slug=self.cleaned_data['slug'], 
#             body=self.cleaned_data['body']
#         )
#         return post

    class Meta:
        model = Post
        fields = ['title', 'slug', 'body', 'tags']
        widgets = {'title': TextInput(), 'slug': TextInput(), 
                   'body': Textarea()}
    
    def clean_slug(self):
        slug = self.cleaned_data['slug'].lower()
        if slug == 'create':
            raise ValidationError("Slug 'create' does not allowed")
        return slug



class TagForm(ModelForm):

    class Meta:
        model = Tag
        fields = ['title', 'slug']
        widgets = {'title': TextInput(), 'slug': TextInput()}