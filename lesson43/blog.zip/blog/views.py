from django.shortcuts import render, redirect
from django.views import View
# from django.http import HttpResponse


from .models import Post, Tag
from .forms import PostForm, TagForm

# Create your views here.


def home_blog(request):
    return render(request, "blog/base_blog.html")
    # if request.method == 'GET':
    #     posts = Post.objects.all()
    #     print(request.method)
    #     # posts_list = []
    #     # for post in posts:
    #     #     posts_list.append(f"{post.title:20}: {post.slug:20}")
    #     # print(f"<Blog homopage\n{'\n'.join(posts_list)}>")
    #     # result = f"<p>{'<br>'.join(posts_list)}</p>"
    #     # return HttpResponse("<h2>Blog homopage</h2>" + result)
    #     return render(request, "blog/posts.html", {'posts': posts})
    # else:
    #     pass


class Posts(View):
    def get(self, request):
        posts = Post.objects.all()
        return render(request, "blog/posts.html", {'posts': posts})
    
    # def post(self, request):
    #     return render(request, "blog/posts.html")


class Tags(View):
    def get(self, request):
        tags = Tag.objects.all()
        return render(request, "blog/tags.html", {'tags': tags})
    

class PostDetail(View):
    def get(self, request, slug):
        post = Post.objects.get(slug=slug)
        return render(request, "blog/post_detail.html", {'post': post}) 
    

class PostCreate(View):
    def get(self, request):
        form = PostForm()
        return render(request, "blog/post_create.html", {'post': form})
    
    def post(self, request):
        # post = Post.objects.create(
        #     title=request.POST['title'],
        #     slug=request.POST['slug'],
        #     body=request.POST['body']
        # )
        bound_form = PostForm(request.POST)
        if bound_form.is_valid():
            post = bound_form.save()
            # return  render(request, "blog/post_detail.html", {'post': post})
            return redirect('post_detail_url', post.slug)
        return  render(request, "blog/post_create.html", {'post': bound_form})
    

class PostUpdate(View):
    def get(self, request, slug):
        post = Post.objects.get(slug__iexact=slug)
        form = PostForm(instance=post)
        return render(request, "blog/post_update.html", {'form': form, 'post': post})
    
    def post(self, request, slug):
        post = Post.objects.get(slug__iexact=slug)
        bound_form = PostForm(request.POST, instance=post)
        if bound_form.is_valid():
            new_post = bound_form.save()
            return redirect(new_post)
        return render(request, "blog/post_update.html", {'form': bound_form, 'post': post})
    

class PostDelete(View):
    def get(self, request, slug):
        post = Post.objects.get(slug__iexact=slug)
        form = PostForm(instance=post)
        return render(request, "blog/post_delete.html", {'form': form, 'post': post})
    
    def post(self, request, slug):
        post = Post.objects.get(slug__iexact=slug)
        post.delete()
        return redirect('posts_list_url')
    

class TagCreate(View):
    def get(self, request):
        form = TagForm()
        return render(request, "blog/tag_create.html", {'tag': form})
    
    def post(self, request):
        bound_form = TagForm(request.POST)
        if bound_form.is_valid():
            tag = bound_form.save()
            # return  render(request, "blog/tag_detail.html", {'tag': tag})
            return redirect('tag_detail_url', tag.slug)
        return  render(request, "blog/tag_create.html", {'tag': bound_form})
    

class TagUpdate(View):
    def get(self, request, slug):
        tag = Tag.objects.get(slug__iexact=slug)
        form = TagForm(instance=tag)
        return render(request, "blog/tag_update.html", {'form': form, 'tag': tag})
    
    def post(self, request, slug):
        tag = Tag.objects.get(slug__iexact=slug)
        bound_form = TagForm(request.POST, instance=tag)
        if bound_form.is_valid():
            new_tag = bound_form.save()
            return redirect(new_tag)
        return render(request, "blog/tag_update.html", {'form': bound_form, 'tag': tag})


class TagDelete(View):
    def get(self, request, slug):
        tag = Tag.objects.get(slug__iexact=slug)
        form = TagForm(instance=tag)
        return render(request, "blog/tag_delete.html", {'form': form, 'tag': tag})
    
    def post(self, request, slug):
        tag = Tag.objects.get(slug__iexact=slug)
        tag.delete()
        return redirect('posts_list_url')


class TagDetail(View):
    def get(self, request, slug):
        tag = Tag.objects.get(slug=slug)
        return render(request, "blog/tag_detail.html", {'tag': tag}) 