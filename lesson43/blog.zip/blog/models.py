from django.db import models
from django.urls import reverse

# Create your models here.

# .all()
# .filter(title='Post')  ->  
# .get(title='Post')  ->  exception

# class Chapter(models.Model):
#     name = models.CharField(max_length=100)


class Post(models.Model):
    title = models.CharField(max_length=100, db_index=True)
    slug = models.SlugField(max_length=100, unique=True)
    body = models.TextField(blank=True, db_index=True)
    published = models.DateTimeField(auto_now_add=True)
    modified = models.DateTimeField(auto_now=True)
    tags = models.ManyToManyField('Tag', blank=True, related_name='posts')
    # chapter = models.ForeignKey(Chapter, on_delete=models.CASCADE)  #

    def __repr__(self):
        return f"<{self.__class__.__name__}: id={self.pk}, title: {self.title:10}>"
    
    def get_absolute_url(self):
        return reverse('post_detail_url', kwargs={"slug": self.slug})
    

class Tag(models.Model):
    title = models.CharField(max_length=100, db_index=True)
    slug = models.SlugField(max_length=100, unique=True)
    # posts = models.ManyToManyField(Post, blank=True, related_name='tags')

    def get_absolute_url(self):
        return reverse('tag_detail_url', kwargs={"slug": self.slug})
