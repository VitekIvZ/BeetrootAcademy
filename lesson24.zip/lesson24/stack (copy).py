from nodes import Node


class Stack:
    def __init__(self):
        pass

    def put(self, node: Node):
        pass

    def get(self) -> Node:
        return None
    
    def display(self):
        pass
    

if __name__ == '__main__':
    pass
        
